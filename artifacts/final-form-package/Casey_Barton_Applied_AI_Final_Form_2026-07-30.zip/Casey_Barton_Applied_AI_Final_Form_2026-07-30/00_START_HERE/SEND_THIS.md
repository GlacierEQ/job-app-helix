# Send This - Casey Barton Applied AI Systems Portfolio

## Primary Link

**https://casey-barton-glaciereq.vercel.app/**

This is the canonical first-stop presentation for recruiters, hiring leaders, senior engineers, ATS systems, and AI reviewers.

## Suggested Message

> Casey Barton is an Applied AI Systems Architect and Forward-Deployed AI Engineer who builds the control, integration, verification, and human-approval layers around AI systems. His portfolio is organized as one evidence-bound presentation rather than a collection of unsupported project claims. Start with the live presentation, then open the resume and roadmap for the human path or the machine contracts for deeper diligence.

## Human Review Order

1. `EXECUTIVE_RESUME.md`
2. `ROADMAP.md`
3. `FINAL_FORM_README.md`
4. `ROLE_POWER_MATRIX.md`
5. `TECHNICAL_PORTFOLIO_BRIEF.md`
6. `CLAIM_REGISTER.md`

## Technical Review Order

1. Live presentation
2. `evidence_ledger.json`
3. `candidate_node.json`
4. `application_spiral.json`
5. `package_mesh.json`
6. Job-App Helix README and test/CI contracts

## Current Truth Boundary

**Verified:** exact 67-repository boundary - one Helix root plus 66 child repositories; complete 66-child rollout partition; AKOS 94/94 tests across Python 3.11-3.13; 21-node README Mesh rollout; live canonical hire surface at https://casey-barton-glaciereq.vercel.app/ (HTTP 200).  
**Candidate proof:** Agent Coordinator 62/62 Python 3.13 tests.  
**Pending:** hosted multi-version coordinator promotion and portfolio-wide deployment, scale, performance, reliability, and customer-impact proof.  
**Not share links:** GitHub Pages (`glaciereq.github.io/job-app-helix/`) is not enabled; `job-application.vercel.app` is a different project.  
**Blocked when infrastructure is absent:** APEX GitHub App bridge activation.

## Licensing

Current GlacierEQ materials are proprietary and source-visible for bona fide evaluation. Employment, commercial licensing, integration, partnership, research, investment, joint-development, acquisition, and separately negotiated source-available or open-source arrangements are open to discussion.

## Direct Contact

The public surface intentionally excludes direct phone and email details. Use the contact card included in the authorized recruiter ZIP or the public GlacierEQ GitHub profile.
